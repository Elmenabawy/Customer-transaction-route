import React from 'react';
import styles from './MiniWeatherCard.module.css';

export default function MiniWeatherCard() {
  return <>
    <h1>MiniWeatherCard</h1>
  </>
}
