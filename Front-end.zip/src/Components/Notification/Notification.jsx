import React from 'react';
import styles from './Notification.module.css';

export default function Notification() {
  return <>
    <h1>Notification</h1>
  </>
}
